// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsound_equalizier.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSound_equalizier_CfgInitialize(XSound_equalizier *InstancePtr, XSound_equalizier_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSound_equalizier_Start(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL) & 0x80;
    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSound_equalizier_IsDone(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSound_equalizier_IsIdle(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSound_equalizier_IsReady(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSound_equalizier_EnableAutoRestart(XSound_equalizier *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL, 0x80);
}

void XSound_equalizier_DisableAutoRestart(XSound_equalizier *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_AP_CTRL, 0);
}

void XSound_equalizier_Set_lpf_gain_V(XSound_equalizier *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_LPF_GAIN_V_DATA, Data);
}

u32 XSound_equalizier_Get_lpf_gain_V(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_LPF_GAIN_V_DATA);
    return Data;
}

void XSound_equalizier_Set_bpf_gain_V(XSound_equalizier *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_BPF_GAIN_V_DATA, Data);
}

u32 XSound_equalizier_Get_bpf_gain_V(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_BPF_GAIN_V_DATA);
    return Data;
}

void XSound_equalizier_Set_hpf_gain_V(XSound_equalizier *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_HPF_GAIN_V_DATA, Data);
}

u32 XSound_equalizier_Get_hpf_gain_V(XSound_equalizier *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_HPF_GAIN_V_DATA);
    return Data;
}

void XSound_equalizier_InterruptGlobalEnable(XSound_equalizier *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_GIE, 1);
}

void XSound_equalizier_InterruptGlobalDisable(XSound_equalizier *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_GIE, 0);
}

void XSound_equalizier_InterruptEnable(XSound_equalizier *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_IER);
    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_IER, Register | Mask);
}

void XSound_equalizier_InterruptDisable(XSound_equalizier *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_IER);
    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_IER, Register & (~Mask));
}

void XSound_equalizier_InterruptClear(XSound_equalizier *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSound_equalizier_WriteReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_ISR, Mask);
}

u32 XSound_equalizier_InterruptGetEnabled(XSound_equalizier *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_IER);
}

u32 XSound_equalizier_InterruptGetStatus(XSound_equalizier *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSound_equalizier_ReadReg(InstancePtr->Ctrl_BaseAddress, XSOUND_EQUALIZIER_CTRL_ADDR_ISR);
}

