// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XSOUND_EQUALIZIER_H
#define XSOUND_EQUALIZIER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsound_equalizier_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_BaseAddress;
} XSound_equalizier_Config;
#endif

typedef struct {
    u32 Ctrl_BaseAddress;
    u32 IsReady;
} XSound_equalizier;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSound_equalizier_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSound_equalizier_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSound_equalizier_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSound_equalizier_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XSound_equalizier_Initialize(XSound_equalizier *InstancePtr, u16 DeviceId);
XSound_equalizier_Config* XSound_equalizier_LookupConfig(u16 DeviceId);
int XSound_equalizier_CfgInitialize(XSound_equalizier *InstancePtr, XSound_equalizier_Config *ConfigPtr);
#else
int XSound_equalizier_Initialize(XSound_equalizier *InstancePtr, const char* InstanceName);
int XSound_equalizier_Release(XSound_equalizier *InstancePtr);
#endif

void XSound_equalizier_Start(XSound_equalizier *InstancePtr);
u32 XSound_equalizier_IsDone(XSound_equalizier *InstancePtr);
u32 XSound_equalizier_IsIdle(XSound_equalizier *InstancePtr);
u32 XSound_equalizier_IsReady(XSound_equalizier *InstancePtr);
void XSound_equalizier_EnableAutoRestart(XSound_equalizier *InstancePtr);
void XSound_equalizier_DisableAutoRestart(XSound_equalizier *InstancePtr);

void XSound_equalizier_Set_lpf_gain_V(XSound_equalizier *InstancePtr, u32 Data);
u32 XSound_equalizier_Get_lpf_gain_V(XSound_equalizier *InstancePtr);
void XSound_equalizier_Set_bpf_gain_V(XSound_equalizier *InstancePtr, u32 Data);
u32 XSound_equalizier_Get_bpf_gain_V(XSound_equalizier *InstancePtr);
void XSound_equalizier_Set_hpf_gain_V(XSound_equalizier *InstancePtr, u32 Data);
u32 XSound_equalizier_Get_hpf_gain_V(XSound_equalizier *InstancePtr);

void XSound_equalizier_InterruptGlobalEnable(XSound_equalizier *InstancePtr);
void XSound_equalizier_InterruptGlobalDisable(XSound_equalizier *InstancePtr);
void XSound_equalizier_InterruptEnable(XSound_equalizier *InstancePtr, u32 Mask);
void XSound_equalizier_InterruptDisable(XSound_equalizier *InstancePtr, u32 Mask);
void XSound_equalizier_InterruptClear(XSound_equalizier *InstancePtr, u32 Mask);
u32 XSound_equalizier_InterruptGetEnabled(XSound_equalizier *InstancePtr);
u32 XSound_equalizier_InterruptGetStatus(XSound_equalizier *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
